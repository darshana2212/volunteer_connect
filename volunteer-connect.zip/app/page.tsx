'use client';

import React from 'react';
import Link from 'next/link';
import { Heart, Users, Building2, DollarSign, ShieldCheck, ArrowRight, Sparkles, MessageSquare, Award } from 'lucide-react';
import { Button } from '@/components/ui/Button';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-emerald-500 selection:text-slate-950 flex flex-col relative overflow-hidden">
      {/* Background Orbs */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-emerald-500/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-[400px] h-[300px] bg-indigo-500/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Header Bar */}
      <header className="sticky top-0 z-30 flex h-20 w-full items-center justify-between border-b border-slate-800/80 bg-slate-950/80 px-6 lg:px-12 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 text-white shadow-lg shadow-emerald-900/40">
            <Heart className="h-5 w-5 fill-current" />
          </div>
          <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
            Volunteer <span className="text-emerald-400">Connect</span>
          </span>
        </div>

        <div className="flex items-center gap-4">
          <Link href="/login">
            <Button variant="ghost" size="md">
              Sign In
            </Button>
          </Link>
          <Link href="/register">
            <Button variant="primary" size="md" icon={<ArrowRight className="w-4 h-4" />}>
              Get Started
            </Button>
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-1 max-w-7xl mx-auto px-6 lg:px-12 py-16 lg:py-24 flex flex-col items-center text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-6 animate-pulse">
          <Sparkles className="w-4 h-4" /> College Computer Science Project Platform
        </div>

        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold text-white tracking-tight leading-[1.15] max-w-4xl">
          Connecting <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-indigo-400 bg-clip-text text-transparent">Volunteers, NGOs & Sponsors</span> in One Platform
        </h1>

        <p className="mt-6 text-lg sm:text-xl text-slate-400 max-w-2xl leading-relaxed">
          Volunteer Connect bridges community volunteers with non-profit organizations and funding sponsors under a unified, role-based platform powered by Supabase Realtime & RLS.
        </p>

        <div className="mt-10 flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
          <Link href="/register">
            <Button variant="primary" size="lg" className="w-full sm:w-auto text-base px-8 py-3.5" icon={<ArrowRight className="w-5 h-5" />}>
              Register Your Account
            </Button>
          </Link>
          <Link href="/login">
            <Button variant="outline" size="lg" className="w-full sm:w-auto text-base px-8 py-3.5">
              Access Dashboard
            </Button>
          </Link>
        </div>

        {/* Roles Feature Cards Grid */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-4 gap-6 w-full text-left">
          <div className="border border-slate-800 rounded-2xl bg-slate-900/60 p-6 flex flex-col justify-between hover:border-emerald-500/40 transition-all backdrop-blur-sm">
            <div>
              <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400 w-fit mb-4">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Volunteer</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Discover active NGO events, submit application requests, track status updates, and chat with event organizers.
              </p>
            </div>
          </div>

          <div className="border border-slate-800 rounded-2xl bg-slate-900/60 p-6 flex flex-col justify-between hover:border-indigo-500/40 transition-all backdrop-blur-sm">
            <div>
              <div className="p-3 rounded-xl bg-indigo-500/10 text-indigo-400 w-fit mb-4">
                <Building2 className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">NGO Representative</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Publish volunteering initiatives, review applicant profiles, select team members, and manage funding goals.
              </p>
            </div>
          </div>

          <div className="border border-slate-800 rounded-2xl bg-slate-900/60 p-6 flex flex-col justify-between hover:border-amber-500/40 transition-all backdrop-blur-sm">
            <div>
              <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400 w-fit mb-4">
                <DollarSign className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Sponsor</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Browse active NGO campaign directories, grant mock donations, and track campaign funding progress percentage.
              </p>
            </div>
          </div>

          <div className="border border-slate-800 rounded-2xl bg-slate-900/60 p-6 flex flex-col justify-between hover:border-purple-500/40 transition-all backdrop-blur-sm">
            <div>
              <div className="p-3 rounded-xl bg-purple-500/10 text-purple-400 w-fit mb-4">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Admin</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Supervise registration approvals, view platform statistics, manage active users and monitor overall system reports.
              </p>
            </div>
          </div>
        </div>

        {/* Highlights Section */}
        <div className="mt-20 border border-slate-800/80 rounded-3xl bg-gradient-to-br from-slate-900/80 via-slate-900/40 to-slate-950 p-8 sm:p-12 w-full text-left flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="max-w-xl space-y-4">
            <h2 className="text-3xl font-bold text-white tracking-tight">
              Realtime Messaging & Secure Role-Based Access
            </h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              Built with Next.js App Router, Supabase PostgreSQL, Realtime channels, and Row Level Security (RLS) policies to ensure connected communication between selected volunteers and NGOs.
            </p>
            <div className="flex flex-wrap gap-4 text-xs font-semibold text-slate-300 pt-2">
              <span className="flex items-center gap-1.5 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
                <MessageSquare className="w-4 h-4 text-emerald-400" /> Supabase Realtime
              </span>
              <span className="flex items-center gap-1.5 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
                <ShieldCheck className="w-4 h-4 text-indigo-400" /> Postgres RLS Policies
              </span>
              <span className="flex items-center gap-1.5 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
                <Award className="w-4 h-4 text-amber-400" /> Role-Based Routing
              </span>
            </div>
          </div>

          <div className="w-full lg:w-auto flex flex-col sm:flex-row gap-4">
            <Link href="/register" className="w-full sm:w-auto">
              <Button variant="primary" size="lg" className="w-full">
                Create Account Now
              </Button>
            </Link>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 px-6 lg:px-12 py-8 text-center text-xs text-slate-500">
        <p>Volunteer Connect — College Computer Science Full-Stack Web Application Project.</p>
      </footer>
    </div>
  );
}
